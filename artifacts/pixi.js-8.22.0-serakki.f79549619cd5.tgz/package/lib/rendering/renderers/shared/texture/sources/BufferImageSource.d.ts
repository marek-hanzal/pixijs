import { TextureSource } from './TextureSource';
import type { ExtensionMetadata } from '../../../../../extensions/Extensions';
import type { TypedArray } from '../../buffer/Buffer';
import type { TextureShapeOptions, TextureSourceOptions } from './TextureSource';
/**
 * Options for creating a BufferImageSource.
 * @category rendering
 * @advanced
 */
export interface BufferSourceOptions extends TextureSourceOptions<TypedArray | ArrayBuffer> {
    width: number;
    height: number;
}
/**
 * A texture source that uses a TypedArray or ArrayBuffer as its resource
 *
 * Without a `format`, the array type picks it: `Float32Array` gives `rgba32float`,
 * 32-bit integer arrays give `rgba32uint`, 16-bit integer arrays give `rgba16uint`, anything else `bgra8unorm`.
 * Integer formats default to `alphaMode: 'no-premultiply-alpha'`, since integer data can't be
 * premultiplied on upload; an explicit `alphaMode` still wins.
 *
 * Pass `depth` for a 3D texture, or `arrayLayerCount` for a 2D array. The buffer holds the slices (or layers)
 * one after another, each in row-major order, so texel `(x, y, z)` sits at index
 * `x + (y * width) + (z * width * height)`. These upload whole, so {@link BufferImageSource#update} takes no range.
 * `rgba32float`, the default for a `Float32Array`, needs an optional feature for linear filtering that PixiJS
 * doesn't request on WebGPU. Use `scaleMode: 'nearest'` with it, or pick `rgba8unorm`, `r8unorm` or
 * `rgba16float` for smooth sampling.
 * @example
 * ```ts
 * const ids = new BufferImageSource({
 *     resource: new Uint32Array([1, 2, 3, 4]),
 *     width: 1,
 *     height: 1,
 *     scaleMode: 'nearest',
 * });
 * ```
 * @example
 * A 3D noise texture for volumetric effects, sampled with `sampler3D` (GLSL) or `texture_3d<f32>` (WGSL):
 *
 * ```ts
 * const size = 64;
 * const data = new Uint8Array(size * size * size * 4);
 *
 * for (let z = 0; z < size; z++)
 * {
 *     for (let y = 0; y < size; y++)
 *     {
 *         for (let x = 0; x < size; x++)
 *         {
 *             const i = (x + (y * size) + (z * size * size)) * 4;
 *
 *             data[i] = data[i + 1] = data[i + 2] = Math.random() * 255;
 *             data[i + 3] = 255;
 *         }
 *     }
 * }
 *
 * const noise = new BufferImageSource({
 *     resource: data,
 *     width: size,
 *     height: size,
 *     depth: size,
 *     format: 'rgba8unorm',
 *     addressMode: 'repeat',
 * });
 *
 * // a fullscreen quad that shows the middle slice
 * const quad = new Geometry({
 *     attributes: {
 *         aPosition: [-1, -1, 1, -1, 1, 1, -1, -1, 1, 1, -1, 1],
 *         aUV: [0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0],
 *     },
 * });
 *
 * const wgsl = `
 *     @group(0) @binding(0) var uNoise: texture_3d<f32>;
 *     @group(0) @binding(1) var uNoiseSampler: sampler;
 *
 *     struct VSOutput { @builtin(position) position: vec4f, @location(0) uv: vec2f };
 *
 *     @vertex fn mainVert(@location(0) aPosition: vec2f, @location(1) aUV: vec2f) -> VSOutput {
 *         return VSOutput(vec4f(aPosition, 0.0, 1.0), aUV);
 *     }
 *
 *     @fragment fn mainFrag(@location(0) uv: vec2f) -> @location(0) vec4f {
 *         return textureSample(uNoise, uNoiseSampler, vec3f(uv, 0.5));
 *     }
 * `;
 *
 * const mesh = new Mesh({
 *     geometry: quad,
 *     shader: Shader.from({
 *         gl: {
 *             vertex: `#version 300 es
 *                 in vec2 aPosition;
 *                 in vec2 aUV;
 *                 out vec2 vUV;
 *                 void main() { vUV = aUV; gl_Position = vec4(aPosition, 0.0, 1.0); }
 *             `,
 *             // no `precision ... sampler3D;` line needed: pixi adds it
 *             fragment: `#version 300 es
 *                 in vec2 vUV;
 *                 uniform sampler3D uNoise;
 *                 out vec4 fragColor;
 *                 void main() { fragColor = texture(uNoise, vec3(vUV, 0.5)); }
 *             `,
 *         },
 *         gpu: {
 *             vertex: { source: wgsl, entryPoint: 'mainVert' },
 *             fragment: { source: wgsl, entryPoint: 'mainFrag' },
 *         },
 *         resources: {
 *             uNoise: noise,
 *             uNoiseSampler: noise.style,
 *         },
 *     }),
 * });
 * ```
 * @category rendering
 * @advanced
 */
export declare class BufferImageSource extends TextureSource<TypedArray | ArrayBuffer> {
    static extension: ExtensionMetadata;
    uploadMethodId: string;
    /**
     * First texel of the range being uploaded by the current {@link BufferImageSource#update} call.
     * @internal
     */
    _updateStart: number;
    /**
     * One past the last texel of the range being uploaded by the current
     * {@link BufferImageSource#update} call. `Infinity` means the whole texture.
     * @internal
     */
    _updateEnd: number;
    constructor(options: BufferSourceOptions & TextureShapeOptions);
    /**
     * Uploads the buffer to the GPU. Call this after changing the data in {@link TextureSource#resource}.
     *
     * The buffer is a flat list of texels in row-major order, so texel `i` sits at
     * `x = i % width`, `y = floor(i / width)`. Pass a texel range to upload only that part of
     * the texture; leave it out to upload everything.
     *
     * The upload happens immediately for every renderer that already holds the texture, and the
     * range applies to this call only. If you change several parts of the buffer, track the dirty
     * span yourself and call `update` once with the combined range. Each call has a fixed cost on
     * top of the bytes it moves, which reaches tens of microseconds on some mobile GPUs. One span
     * usually beats many small calls.
     *
     * Partial uploads assume the buffer holds exactly `width * height` texels. A 3D texture or 2D array
     * always uploads whole, so it takes no range.
     * @example
     * ```ts
     * const data = new Float32Array(4096 * 64 * 4);
     * const source = new BufferImageSource({ resource: data, width: 4096, height: 64 });
     *
     * // change texels 100 to 115 (4 floats per rgba32float texel)
     * data.fill(1, 100 * 4, 116 * 4);
     *
     * // upload only those 16 texels
     * source.update(100, 116);
     * ```
     * @param start - index of the first texel to upload
     * @param end - index one past the last texel to upload (exclusive, like `TypedArray.subarray`)
     */
    update(start?: number, end?: number): void;
    static test(resource: any): resource is TypedArray | ArrayBuffer;
}
