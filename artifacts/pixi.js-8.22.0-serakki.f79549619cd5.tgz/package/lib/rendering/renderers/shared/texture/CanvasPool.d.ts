import type { ICanvas, ICanvasRenderingContext2DSettings } from '../../../../environment/canvas/ICanvas';
import type { ICanvasRenderingContext2D } from '../../../../environment/canvas/ICanvasRenderingContext2D';
import type { Size } from '../../../../maths/misc/Size';
/**
 * A utility type that represents a canvas and its rendering context.
 * @category rendering
 * @internal
 */
export interface CanvasAndContext {
    /** The canvas element. */
    canvas: ICanvas;
    /** The rendering context of the canvas. */
    context: ICanvasRenderingContext2D;
}
/**
 * CanvasPool is a utility class that manages a pool of reusable canvas elements
 * @category rendering
 * @internal
 */
export declare class CanvasPoolClass {
    canvasOptions: ICanvasRenderingContext2DSettings;
    /** idle canvases, keyed by size */
    private readonly _buckets;
    /** the screens this pool is sizing its canvases for */
    private readonly _screens;
    private _enableFullScreen;
    constructor(canvasOptions?: ICanvasRenderingContext2DSettings);
    /**
     * Has no effect. The pool sizes canvases to the screens registered with
     * {@link CanvasPoolClass#setScreenSize|setScreenSize}.
     * @deprecated since 8.21.0
     */
    get enableFullScreen(): boolean;
    set enableFullScreen(value: boolean);
    /**
     * Creates texture with params that were specified in pool constructor.
     * @param pixelWidth - Width of texture in pixels.
     * @param pixelHeight - Height of texture in pixels.
     */
    private _createCanvasAndContext;
    /**
     * Gets a Power-of-Two canvas or screen sized canvas
     * @param minWidth - The minimum width of the canvas.
     * @param minHeight - The minimum height of the canvas.
     * @param resolution - The resolution of the canvas.
     * @returns The new canvas and its context.
     */
    getOptimalCanvasAndContext(minWidth: number, minHeight: number, resolution?: number): CanvasAndContext;
    /**
     * The backing size, in physical pixels, that
     * {@link CanvasPoolClass#getOptimalCanvasAndContext|getOptimalCanvasAndContext} would allocate for a request,
     * without taking a canvas from the pool.
     *
     * Each axis is the next power of two, or the smallest registered screen the request fits inside
     * (see {@link CanvasPoolClass#setScreenSize|setScreenSize}).
     * @param minWidth - The minimum width of the canvas.
     * @param minHeight - The minimum height of the canvas.
     * @param resolution - The resolution of the canvas.
     * @returns The width and height the pooled canvas would have, in physical pixels.
     */
    getOptimalSize(minWidth: number, minHeight: number, resolution?: number): Size;
    /**
     * Place a canvas back into the pool.
     * @param canvasAndContext
     */
    returnCanvasAndContext(canvasAndContext: CanvasAndContext): void;
    /**
     * Registers the screen size of a renderer with the pool, in physical pixels.
     *
     * While a screen is registered, a request that fits inside it on an axis is given that screen's size on
     * that axis instead of the next power of two, which stops a full screen canvas from being allocated far
     * larger than the screen. Requests larger than every registered screen on an axis keep the power of two
     * size - the pool never rounds a request up to a screen it does not fit in.
     * @param rendererUid - The uid of the renderer, used to update or remove this screen later.
     * @param pixelWidth - The width of the screen in physical pixels.
     * @param pixelHeight - The height of the screen in physical pixels.
     */
    setScreenSize(rendererUid: number, pixelWidth: number, pixelHeight: number): void;
    /**
     * Removes a screen previously registered with
     * {@link CanvasPoolClass#setScreenSize|setScreenSize}, dropping any idle canvases that were
     * only being kept for it.
     * @param rendererUid - The uid the screen was registered with.
     */
    removeScreen(rendererUid: number): void;
    /** Clears the pool. */
    clear(): void;
    /**
     * Drops the idle canvases in every bucket that has a non power of two dimension matching no live
     * screen. Power of two buckets are always kept, as any request can fall back to them.
     */
    private _pruneScreenCanvases;
}
/**
 * CanvasPool is a utility class that manages a pool of reusable canvas elements
 * @category rendering
 * @internal
 */
export declare const CanvasPool: CanvasPoolClass;
