import EventEmitter from 'eventemitter3';
import type { BindResource } from '../../gpu/shader/BindResource';
import type { Buffer } from './Buffer';
/**
 * A resource that can be bound to a bind group and used in a shader.
 * Whilst a buffer can be used as a resource, this class allows you to specify an offset and size of the buffer to use.
 * This is useful if you have a large buffer and only part of it is used in a shader.
 *
 * This resource, will listen for changes on the underlying buffer and emit a itself if the buffer changes shape.
 * @example
 *
 * const buffer = new Buffer({
 *     data: new Float32Array(1000),
 *    usage: BufferUsage.UNIFORM,
 * });
 * // Create a buffer resource that uses the first 100 bytes of a buffer
 * const bufferResource = new BufferResource({
 *    buffer,
 *    offset: 0,
 *    size: 100,
 * });
 * @category rendering
 * @advanced
 */
export declare class BufferResource extends EventEmitter<{
    change: BindResource;
}> implements BindResource {
    /**
     * emits when the underlying buffer has changed shape (i.e. resized)
     * letting the renderer know that it needs to discard the old buffer on the GPU and create a new one
     * @event change
     */
    /** a unique id for this uniform group used through the renderer */
    readonly uid: number;
    /**
     * a resource type, used to identify how to handle it when its in a bind group / shader resource
     * @internal
     */
    readonly _resourceType = "bufferResource";
    /**
     * the resource id used internally by the renderer to build bind group keys
     * @internal
     */
    _resourceId: number;
    /** the underlying buffer that this resource is using */
    buffer: Buffer;
    /**
     * the byte offset into the buffer this resource starts at, defaulting to 0.
     * Must be a multiple of `renderer.limits.minUniformBufferOffsetAlignment`.
     */
    readonly offset: number;
    /** the number of bytes this resource covers. If not provided, it covers the rest of the buffer after `offset`. */
    readonly size: number;
    /**
     * A cheeky hint to the GL renderer to let it know this is a BufferResource
     * @internal
     */
    readonly _bufferResource = true;
    /**
     * Has the Buffer resource been destroyed?
     * @readonly
     */
    destroyed: boolean;
    /**
     * Whether the renderer that created this resource destroyed it as part of its own teardown
     *
     * The renderer sets this right before the destroy, so bind groups still holding the resource
     * release it without the misuse warning. Nothing their owner did caused the destroy.
     * @internal
     */
    _destroyedByRenderer: boolean;
    /**
     * Create a new Buffer Resource.
     * @param options - The options for the buffer resource
     * @param options.buffer - The underlying buffer that this resource is using
     * @param options.offset - The byte offset into the buffer this resource starts at, defaulting to 0.
     * Must be a multiple of `renderer.limits.minUniformBufferOffsetAlignment`.
     * @param options.size - The number of bytes this resource covers.
     * If not provided, it covers the rest of the buffer after `offset`.
     */
    constructor({ buffer, offset, size }: {
        buffer: Buffer;
        offset?: number;
        size?: number;
    });
    /**
     * The GC tracks the underlying buffer, not this resource — a GC stamp here (see
     * BindGroup._touch) must land on the buffer, or the GC collects it while cached
     * bind groups still reference it.
     * @internal
     */
    get _gcLastUsed(): number;
    set _gcLastUsed(value: number);
    protected onBufferChange(): void;
    /**
     * Destroys this resource. Make sure the underlying buffer is not used anywhere else
     * if you want to destroy it as well, or code will explode
     * @param destroyBuffer - Should the underlying buffer be destroyed as well?
     */
    destroy(destroyBuffer?: boolean): void;
}
