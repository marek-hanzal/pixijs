import { STENCIL_MODES } from '../../shared/state/const';
import type { TextureSource } from '../../shared/texture/sources/TextureSource';
/**
 * A class which holds the canvas contexts and textures for a render target.
 * @category rendering
 * @ignore
 */
export declare class GpuRenderTarget {
    contexts: GPUCanvasContext[];
    /**
     * Per canvas attachment, the canvas texture the last pass drew into. A canvas hands out a new, empty
     * texture each frame, so a different one means nothing has been drawn this frame yet.
     */
    canvasTextures: GPUTexture[];
    msaaTextures: TextureSource[];
    msaa: boolean;
    /**
     * The user marked this multisampled target `transient` (single pass, never reopened), so its MSAA
     * depth/stencil is discarded too. Read once from the colour texture, like `msaa`. Separate from each
     * `msaaTextures[i].transient`, which is also set on every tile-based GPU.
     */
    transient: boolean;
    msaaSamples: number;
    width: number;
    height: number;
    descriptor: GPURenderPassDescriptor;
    /**
     * Per MSAA colour attachment, the copy of its resolved image that a reopened pass draws back in (see
     * GpuMsaaRestore), as FilterSystem's `backTexture` is a copy of what a filter draws over. Created on the
     * first restore, then resized and destroyed with `msaaTextures`.
     */
    msaaBackTextures: TextureSource[];
    /**
     * The stencil state the stencil system and the mask pipe track for this target on this renderer.
     * It lives here rather than in a uid-keyed record so it is restored when the target is bound again
     * and freed with the backend object when the target dies.
     */
    stencilMode: STENCIL_MODES;
    /** the stencil reference value that goes with `stencilMode` */
    stencilReference: number;
    /** how many stencil masks are currently pushed on this target */
    maskStackIndex: number;
}
