import type { TextureSource } from '../../shared/texture/sources/TextureSource';
import type { WebGPURenderer } from '../WebGPURenderer';
/**
 * Copies depth that `copyTextureToTexture` can't, by drawing it.
 *
 * WebGPU only copies depth textures whole, and only between textures with the same sample count, and it has no
 * depth resolve. So `copyDepthTexture` from an antialiased target, or of a region, draws a full-screen triangle
 * into the destination that writes each pixel's depth from the source. A multisampled source gives sample 0:
 * what WebGL's `blitFramebuffer` resolve gives, and the resolve mode every Vulkan driver supports; keeping the
 * nearest of the samples instead costs 1.5–2.8× as much on phones. Only depth is copied: a destination's stencil
 * is left as it was.
 * @category rendering
 * @ignore
 */
export declare class GpuDepthCopy {
    private readonly _renderer;
    private readonly _device;
    /** by source sample count */
    private readonly _variants;
    /** one bind group per source texture, dropped with the texture when a resize replaces it */
    private readonly _bindGroups;
    /** reused by every copy, so a copy allocates nothing once its pipeline and bind group exist */
    private readonly _depthStencilAttachment;
    private readonly _passDescriptor;
    constructor(renderer: WebGPURenderer);
    /**
     * Records the copy of a region of a depth texture into another depth texture. Must be recorded outside a
     * render pass.
     * @param commandEncoder - the encoder to record the copy on
     * @param source - the depth texture to read, created with `TEXTURE_BINDING`; it may be multisampled
     * @param destination - the single-sample texture to write depth into; it must have a depth aspect
     * @param originSrc - the top left of the region in the source
     * @param originSrc.x - its x, in pixels
     * @param originSrc.y - its y, in pixels
     * @param size - the size of the region
     * @param size.width - its width, in pixels
     * @param size.height - its height, in pixels
     * @param originDest - where the region lands in the destination
     * @param originDest.x - its x, in pixels
     * @param originDest.y - its y, in pixels
     */
    copy(commandEncoder: GPUCommandEncoder, source: TextureSource, destination: TextureSource, originSrc: {
        x: number;
        y: number;
    }, size: {
        width: number;
        height: number;
    }, originDest: {
        x: number;
        y: number;
    }): void;
    private _createVariant;
    private _createPipeline;
}
