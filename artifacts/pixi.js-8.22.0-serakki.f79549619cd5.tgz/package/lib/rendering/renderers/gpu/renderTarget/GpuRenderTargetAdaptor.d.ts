import { TextureSource } from '../../shared/texture/sources/TextureSource';
import { GpuRenderTarget } from './GpuRenderTarget';
import type { RgbaArray } from '../../../../color/Color';
import type { Rectangle } from '../../../../maths/shapes/Rectangle';
import type { CLEAR_OR_BOOL } from '../../gl/const';
import type { RenderTarget } from '../../shared/renderTarget/RenderTarget';
import type { RenderTargetAdaptor, RenderTargetSystem } from '../../shared/renderTarget/RenderTargetSystem';
import type { Texture } from '../../shared/texture/Texture';
import type { WebGPURenderer } from '../WebGPURenderer';
/**
 * The WebGPU adaptor for the render target system. Allows the Render Target System to
 * be used with the WebGPU renderer
 * @category rendering
 * @ignore
 */
export declare class GpuRenderTargetAdaptor implements RenderTargetAdaptor<GpuRenderTarget> {
    private _renderTargetSystem;
    private _renderer;
    /**
     * The render target the currently open render pass is rendering to (plus the subresource it is
     * bound to). Used to make {@link startRenderPass} idempotent: binding the same target/mip/layer
     * again with no clear reuses the open pass instead of tearing it down and beginning a new one.
     * Reset to `null` whenever the pass is closed ({@link finishRenderPass}).
     */
    private _activePass;
    /** Restores discarded MSAA colour buffers on reopen. Created on first use, per device. */
    private _msaaRestore;
    /** Draws the depth copies `copyTextureToTexture` can't make. Created on first use, per device. */
    private _depthCopy;
    init(renderer: WebGPURenderer, renderTargetSystem: RenderTargetSystem<GpuRenderTarget>): void;
    /** Drops the MSAA helpers, whose pipelines belong to the old device. The next use makes new ones. */
    contextChange(): void;
    destroy(): void;
    copyToTexture(sourceRenderSurfaceTexture: RenderTarget, destinationTexture: Texture, originSrc: {
        x: number;
        y: number;
    }, size: {
        width: number;
        height: number;
    }, originDest: {
        x: number;
        y: number;
    }): Texture<TextureSource<any>>;
    copyDepthTexture(source: RenderTarget, destination: Texture, originSrc: {
        x: number;
        y: number;
    }, size: {
        width: number;
        height: number;
    }, originDest: {
        x: number;
        y: number;
    }): void;
    startRenderPass(renderTarget: RenderTarget, clear?: CLEAR_OR_BOOL, clearColor?: RgbaArray, viewport?: Rectangle, mipLevel?: number, layer?: number): void;
    finishRenderPass(): void;
    /**
     * Begins a pass whose MSAA colour must be restored: copies each resolved texture in `restore` into the
     * target's back textures, begins the pass, and draws them back in before anything else (see GpuMsaaRestore).
     * @param renderTarget - the target being reopened
     * @param restore - the colour attachments to restore
     * @param commandEncoder - the encoder to record the copies on, with no pass open
     * @param beginPass - begins the pass on the same encoder
     * @returns the begun pass
     */
    private _beginRestoredPass;
    /**
     * returns the gpu texture for a color texture in the render target, the first by default
     * mainly used by the filter manager to copy the texture for blending
     * @param renderTarget
     * @param index - the color attachment to get
     * @returns a gpu texture
     */
    private _getGpuColorTexture;
    getDescriptor(renderTarget: RenderTarget, clear: CLEAR_OR_BOOL, clearValue: RgbaArray, mipLevel?: number, layer?: number): GPURenderPassDescriptor;
    /**
     * Builds the pass descriptor, along with the MSAA colour attachments it opens with `clear` in place of
     * `load`. Those buffers were discarded, so the pass must restore them before drawing.
     * @param renderTarget - the target to render to
     * @param clear - what to clear
     * @param clearValue - the colour to clear to
     * @param mipLevel - the mip level to render to
     * @param layer - the array layer to render to
     */
    private _buildDescriptor;
    clear(renderTarget: RenderTarget, clear?: CLEAR_OR_BOOL, clearColor?: RgbaArray, viewport?: Rectangle, mipLevel?: number, layer?: number): void;
    initGpuRenderTarget(renderTarget: RenderTarget): GpuRenderTarget;
    /**
     * Sets up a depth/stencil texture for an MSAA target before its GPU texture is created: 4 samples, and
     * the transient usage bit when the user marked the target single-pass. Both are fixed at creation, so this
     * runs when a pass descriptor is built, just before the depth/stencil view is first made.
     * @param renderTarget - the target whose depth/stencil texture to set up
     * @param gpuRenderTarget - its backend target
     */
    private _prepareDepthStencil;
    destroyGpuRenderTarget(gpuRenderTarget: GpuRenderTarget): void;
    ensureDepthStencilTexture(renderTarget: RenderTarget): void;
    resizeGpuRenderTarget(renderTarget: RenderTarget): void;
}
