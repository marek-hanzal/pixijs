import type { RenderTarget } from '../../shared/renderTarget/RenderTarget';
import type { WebGPURenderer } from '../WebGPURenderer';
/**
 * Restores a multisampled colour buffer from its resolved image.
 *
 * A transient MSAA colour buffer (every one on a tile-based GPU, and ones the user marks `transient`
 * elsewhere) is cleared on load and discarded on store, which skips writing the 4-sample buffer back to
 * memory. The resolved single-sample texture is still stored, so a pass that reopens the target (a filter
 * popping back, a mask adding stencil, `clear: false`) copies the resolved texture into the target's back
 * texture and draws it back in as the pass's first draw, instead of loading samples that were never written.
 * On tile-based GPUs this beats storing and loading the 4-sample buffer even when a target is reopened every
 * frame; on GPUs that keep MSAA in video memory it doesn't, which is why they store it by default.
 *
 * The draw is a full-screen `textureLoad` with no blending, so every pixel gets its resolved colour back.
 * The back textures belong to the targets (`GpuRenderTarget.msaaBackTextures`); this holds only the
 * pipelines and bind groups.
 * @category rendering
 * @ignore
 */
export declare class GpuMsaaRestore {
    private readonly _renderer;
    private readonly _device;
    private readonly _layout;
    private readonly _pipelineLayout;
    /** per attachment layout, one pipeline per colour attachment */
    private readonly _pipelines;
    private readonly _modules;
    /** one bind group per back texture, dropped with the texture when a resize replaces it */
    private readonly _bindGroups;
    constructor(renderer: WebGPURenderer);
    /**
     * Copies one colour attachment's resolved image into the target's back texture, creating it on first use
     * at the attachment's size and format. Must be recorded outside a render pass.
     * @param commandEncoder - the encoder to record the copy on
     * @param renderTarget - the target being reopened
     * @param index - the colour attachment to copy
     * @param resolved - the attachment's resolved texture
     */
    copy(commandEncoder: GPUCommandEncoder, renderTarget: RenderTarget, index: number, resolved: GPUTexture): void;
    /**
     * Draws one colour attachment's back texture into the multisampled buffer. Must be the first draw of the
     * pass, before any viewport or scissor is set.
     * @param pass - the pass that was just begun
     * @param renderTarget - the target the pass renders to
     * @param index - the colour attachment to restore, copied by {@link GpuMsaaRestore.copy}
     */
    draw(pass: GPURenderPassEncoder, renderTarget: RenderTarget, index: number): void;
    private _getModule;
    private _createPipeline;
}
