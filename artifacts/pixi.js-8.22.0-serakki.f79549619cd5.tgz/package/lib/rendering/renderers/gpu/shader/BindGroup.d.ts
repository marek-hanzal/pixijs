import type { GpuBindGroupEntry } from '../BindGroupSystem';
import type { BindResource } from './BindResource';
/**
 * The binding number of each resource in a {@link BindGroup}, by name: the same shape as one group of
 * {@link GpuProgram#layout}.
 * @category rendering
 * @advanced
 */
export type BindGroupLayout = Record<string, number>;
/**
 * A bind group is a collection of resources that are bound together for use by a shader.
 * They are essentially a wrapper for the WebGPU BindGroup class. But with the added bonus
 * that WebGL can also work with them.
 *
 * Bind groups resources must implement the {@link BindResource} interface.
 * The following resources are supported:
 * - {@link TextureSource}
 * - {@link TextureStyle}
 * - {@link Buffer}
 * - {@link BufferResource}
 * - {@link UniformGroup}
 *
 * Keyed by name, as in the examples below, the group knows which binding each name is, and the
 * renderers match a shader's bindings to the group's resources by name. The shader's own binding
 * numbers then don't matter, so shaders that number the same bindings differently, or declare only
 * some of them, can share one group. Declare every binding the group will ever hold; `null` marks
 * one to be set later.
 *
 * The names must be the ones the shader declares its bindings with. A name the shader doesn't
 * declare is ignored, and a shader binding the group has no name for gets no resource: WebGPU
 * throws, and WebGL draws without it.
 *
 * On WebGL, set a binding declared `null` before a shader first draws with the group, or declare it
 * with a placeholder resource. WebGL works out what to bind the first time a program is used, and a
 * binding still empty then is never bound, even once it is set.
 *
 * Keyed by number, the group has no layout and a shader reads binding `n` from the group's binding `n`.
 *
 * This bind group class will also watch for changes in its resources ensuring that the changes
 * are reflected in the WebGPU BindGroup.
 * @see https://gpuweb.github.io/gpuweb/#dictdef-gpubindgroupdescriptor
 * @example
 * ```ts
 * // Create a bind group with a single texture and sampler
 * const bindGroup = new BindGroup({
 *     uTexture: texture.source,
 *     uSampler: texture.source.style,
 * });
 * ```
 * @example
 * ```ts
 * // One group shared by several shaders; `instances` is declared now and set later
 * const global = new BindGroup({ camera, lights, shadowMap, shadowSampler, instances: null });
 *
 * global.setResource(batchInstances, 'instances');
 * ```
 * @category rendering
 * @advanced
 */
export declare class BindGroup {
    /**
     * The resources that are bound together for use by a shader, keyed by binding number.
     *
     * Treat this as read-only and use {@link BindGroup#setResource} to add or replace a resource.
     * A direct write skips the bind group's change tracking: the GPU bind group is not rebuilt,
     * and the renderer never syncs the new resource's uniforms or marks it as in use.
     * @readonly
     */
    resources: Record<string, BindResource>;
    /**
     * The binding numbers in use in {@link BindGroup#resources}, ascending. Binding numbers can
     * have gaps, so per-draw loops index this list instead of running `for...in` over
     * `resources`, which builds a fresh key list on every call for integer keys.
     * @internal
     */
    get _resourceKeys(): number[];
    private _resourceKeysValue;
    /**
     * The binding numbers {@link BindGroup#_touch} stamps: every binding but the samplers. The GC
     * never collects a `TextureStyle` (`GpuTextureSystem` caches one `GPUSampler` per style id, outside
     * the GC), so stamping one does nothing, and a group of texture and sampler pairs would stamp twice
     * as many resources as it needs. Rebuilt when a binding is added or changes type.
     */
    private _touchKeysValue;
    /**
     * One half of the key used internally to match this group up to a WebGPU BindGroup: a hash of
     * every binding number and the id of the resource bound there, kept up to date as resources
     * are set and as they change. Two groups holding the same resources at the same bindings have
     * the same key, and share one WebGPU BindGroup.
     * @internal
     */
    _keyLow: number;
    /**
     * The other half of the key, see {@link BindGroup#_keyLow}.
     * @internal
     */
    _keyHigh: number;
    /**
     * The cache entry {@link BindGroupSystem} last resolved this group to, so binding a group that
     * has not changed skips the cache lookup. Cleared whenever the key moves.
     * @internal
     */
    _gpuEntry: GpuBindGroupEntry | null;
    /**
     * The program layout and group index {@link BindGroup#_gpuEntry} was resolved for.
     * @internal
     */
    _gpuEntryLayoutKey: number;
    /**
     * The resource id each binding is in the key with, by binding number. A resource's id can move
     * before this group hears about it, so the mix taken out is this one, never the resource's own.
     */
    private readonly _keyedIds;
    /**
     * The binding number of each resource by name, in the order the constructor was given them, or
     * `null` for a group keyed by number. With a layout, a shader's bindings are matched to this
     * group's resources by name, whatever numbers the shader gives them.
     *
     * WebGL works out what to bind once per program, from the first shader drawn with it. Shaders that
     * share a program must key the group at each group index the same way: all by number, or all by
     * name with the names in the same order.
     * @readonly
     */
    readonly layout: BindGroupLayout | null;
    /**
     * Create a new instance of the Bind Group.
     * @param resources - The resources that are bound together for use by a shader, keyed by binding
     * name or by binding number. Don't mix the two: the first key decides which the group is. Either
     * way they take binding numbers `0, 1, 2...` in order. By name, the keys are the shader's binding
     * names, and a `null` declares a binding to be set later with {@link BindGroup#setResource}.
     */
    constructor(resources?: Record<string, BindResource | null>);
    /**
     * Set a resource at a given index. This function will
     * ensure that listeners will be removed from the current resource
     * and added to the new resource.
     * @param resource - The resource to set.
     * @param index - The binding number to set the resource at, or its name in a group keyed by name.
     */
    setResource(resource: BindResource, index: number | string): void;
    /**
     * Sets a resource at a given index without listening for its changes.
     *
     * {@link BindGroup#setResource} adds a `change` listener to every resource it holds, so the group
     * re-keys when the resource changes or is destroyed. That listener costs more than the bind for a
     * slot that is re-pointed on every draw, such as a pass that binds this frame's pooled texture,
     * draws, and puts a placeholder back. Use this form for such a slot, and re-point it before the
     * resource changes or is destroyed. A subclass that watches its own resources can instead pass
     * every change of a resource it holds to `onResourceChange`.
     * @param resource - The resource to set.
     * @param index - The index to set the resource at.
     */
    setResourceUnwatched(resource: BindResource, index: number): void;
    /**
     * Swaps the id a binding is in the key with.
     * @param index - The binding number.
     * @param id - The id of the resource now bound there, -1 for a destroyed resource's null slot.
     */
    private _rekey;
    /**
     * Returns the resource at the current specified index.
     * @param index - The binding number of the resource to get, or its name in a group keyed by name.
     * @returns - The resource at the specified index.
     */
    getResource(index: number | string): BindResource;
    /**
     * The binding number a name has in this group's layout. A name the group doesn't have is a
     * mistake, and this is the only moment it is visible: by number nothing checks.
     * @param name - The binding name.
     */
    private _bindingOf;
    /**
     * Used internally to 'touch' each resource but the samplers, so the GC knows this bind group still
     * uses them. See {@link BindGroup#_touchKeysValue}.
     * @param now - The current time in milliseconds.
     * @internal
     */
    _touch(now: number): void;
    /** The binding numbers {@link BindGroup#_touch} stamps, see {@link BindGroup#_touchKeysValue}. */
    private get _touchKeys();
    /** Destroys this bind group and removes all listeners. */
    destroy(): void;
    protected onResourceChange(resource: BindResource): void;
}
