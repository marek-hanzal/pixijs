import { ExtensionType } from '../../../extensions/Extensions';
import type { RenderTarget } from '../shared/renderTarget/RenderTarget';
import type { STENCIL_MODES } from '../shared/state/const';
import type { System } from '../shared/system/System';
import type { WebGPURenderer } from './WebGPURenderer';
/**
 * This manages the stencil buffer. Used primarily for masking
 * @category rendering
 * @advanced
 */
export declare class GpuStencilSystem implements System {
    /** @ignore */
    static extension: {
        readonly type: readonly [ExtensionType.WebGPUSystem];
        readonly name: "stencil";
    };
    private readonly _renderer;
    private _activeRenderTarget;
    /** the backend counterpart of the active render target, which carries the stencil state being tracked */
    private _activeGpuRenderTarget;
    constructor(renderer: WebGPURenderer);
    protected contextChange(): void;
    protected onRenderTargetChange(renderTarget: RenderTarget): void;
    setStencilMode(stencilMode: STENCIL_MODES, stencilReference: number): void;
    destroy(): void;
}
