import { ExtensionType } from '../../../extensions/Extensions';
import type { GCable } from '../shared/GCSystem';
import type { System } from '../shared/system/System';
import type { GPU } from './GpuDeviceSystem';
import type { BindGroup } from './shader/BindGroup';
import type { GpuProgram } from './shader/GpuProgram';
import type { WebGPURenderer } from './WebGPURenderer';
/**
 * A cached native bind group, shaped so the renderer's GC can sweep it. Cache keys are built from
 * resource ids that change whenever a resource is unloaded, resized or destroyed, so an entry that
 * stops being requested can never be hit again and would otherwise live as long as the device.
 * @internal
 */
export declare class GpuBindGroupEntry implements GCable {
    gpuBindGroup: GPUBindGroup;
    _gcLastUsed: number;
    readonly autoGarbageCollect = true;
    /** Part of the {@link GCable} contract; a cached bind group owns no per-renderer GPU data. */
    readonly _gpuData: GCable['_gpuData'];
    /** The {@link BindGroup#_keyLow} of the resources the native group was built from. */
    readonly keyLow: number;
    /** The {@link BindGroup#_keyHigh} of the resources the native group was built from. */
    readonly keyHigh: number;
    /** The program layout and group index the native group was built for. */
    readonly layoutKey: number;
    /**
     * The id of the cache that built the native group. Each renderer, and each device a renderer restores,
     * gets a new cache id, so an entry answers only for the system and device that built it.
     */
    readonly cacheId: number;
    constructor(gpuBindGroup: GPUBindGroup, now: number, keyLow: number, keyHigh: number, layoutKey: number, cacheId: number);
    /**
     * Native bind groups have no destroy; dropping the reference is the whole release. Anything
     * still holding the group (a recorded render bundle, a graphics batch) keeps it alive, and the
     * next immediate-mode bind simply recreates the cache entry.
     */
    unload(): void;
}
/**
 * This manages the WebGPU bind groups. this is how data is bound to a shader when rendering
 * @category rendering
 * @advanced
 */
export declare class BindGroupSystem implements System {
    /** @ignore */
    static extension: {
        readonly type: readonly [ExtensionType.WebGPUSystem];
        readonly name: "bindGroup";
    };
    private readonly _renderer;
    /**
     * The cached native bind groups, one per slot. A slot is 30 bits of the content and layout keys,
     * which keeps it a small integer; the entry holds the whole of both keys and a hit compares them.
     * Two different keys that land on one slot replace each other.
     */
    private _hash;
    private _gpu;
    private _cacheId;
    constructor(renderer: WebGPURenderer);
    protected contextChange(gpu: GPU): void;
    getBindGroup(bindGroup: BindGroup, program: GpuProgram, groupIndex: number): GPUBindGroup;
    private _createBindGroup;
    destroy(): void;
}
