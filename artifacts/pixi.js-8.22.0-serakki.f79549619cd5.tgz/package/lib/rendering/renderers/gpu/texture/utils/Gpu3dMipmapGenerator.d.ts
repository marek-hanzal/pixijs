/**
 * Throws unless a 3D texture can have its mipmaps generated. WebGPU writes them with a compute shader,
 * so the texture needs `storage: true` and a format the shader can both sample linearly and store.
 * @param format - the texture's format
 * @param storage - whether the texture can be bound as a storage texture
 * @internal
 */
export declare function assertMipmap3dTexture(format: GPUTextureFormat, storage: boolean): void;
/**
 * Generates mipmaps for a 3D GPUTexture with a compute shader.
 *
 * One compute pass with one dispatch per mip, one thread per output voxel. Each dispatch takes a
 * linear sample at the centre of every 2×2×2 box of the previous mip and stores it in the next.
 *
 * The texture must have been created with `storage: true` and a full mip chain.
 * @category rendering
 * @ignore
 */
export declare class Gpu3dMipmapGenerator {
    private readonly _device;
    private readonly _sampler;
    private readonly _pipelines;
    constructor(device: GPUDevice);
    private _getMipmapPipeline;
    /**
     * Fills mip levels 1..n of a 3D texture from level 0.
     * @param texture - a 3D texture with `STORAGE_BINDING` and more than one mip level
     */
    generateMipmap(texture: GPUTexture): void;
}
