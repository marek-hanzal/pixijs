import { ExtensionType } from '../../../../extensions/Extensions';
import { Texture } from '../../shared/texture/Texture';
import { GlTexture } from './GlTexture';
import type { ICanvas } from '../../../../environment/canvas/ICanvas';
import type { System } from '../../shared/system/System';
import type { CanvasGenerator, GetPixelsOutput } from '../../shared/texture/GenerateCanvas';
import type { TextureSource } from '../../shared/texture/sources/TextureSource';
import type { BindableTexture } from '../../shared/texture/Texture';
import type { GlRenderingContext } from '../context/GlRenderingContext';
import type { WebGLRenderer } from '../WebGLRenderer';
import type { GLTextureUploader } from './uploaders/GLTextureUploader';
/**
 * The system for managing textures in WebGL.
 * @category rendering
 * @advanced
 */
export declare class GlTextureSystem implements System, CanvasGenerator {
    /** @ignore */
    static extension: {
        readonly type: readonly [ExtensionType.WebGLSystem];
        readonly name: "texture";
    };
    /**
     * Optional uploaders registered via {@link ExtensionType.TextureUploaderWebGL}. Each entry is
     * merged into {@link _uploads} at construction time, so import order matters: register the
     * extension before creating the renderer.
     * @internal
     */
    static readonly uploadExtensions: Record<string, GLTextureUploader>;
    private readonly _renderer;
    private readonly _managedTextures;
    /**
     * @deprecated since 8.15.0
     */
    get managedTextures(): Readonly<TextureSource[]>;
    private _glSamplers;
    private _boundTextures;
    /** Bit `n` is set while unit `n` may hold an integer-format texture; `resetState` sets every unit. */
    private _integerUnits;
    private _activeTextureLocation;
    private _boundSamplers;
    private readonly _uploads;
    private _gl;
    private _mapFormatToInternalFormat;
    private _mapFormatToType;
    private _mapFormatToFormat;
    private _mapViewDimensionToGlTarget;
    private _premultiplyAlpha;
    private readonly _useSeparateSamplers;
    constructor(renderer: WebGLRenderer);
    protected contextChange(gl: GlRenderingContext): void;
    /**
     * Initializes a texture source, if it has already been initialized nothing will happen.
     * @param source - The texture source to initialize.
     * @returns The initialized texture source.
     */
    initSource(source: TextureSource): void;
    bind(texture: BindableTexture, location?: number): void;
    bindSource(source: TextureSource, location?: number): void;
    /**
     * Binds the empty texture over every integer texture on unit `location` and above
     *
     * WebGL fails a draw when a float sampler's unit holds an integer texture, even if the shader
     * never samples it. Call this after binding a batch's textures when the shader declares more
     * samplers than the batch binds.
     * @param location - The first texture unit to check.
     */
    unbindIntegerTextures(location: number): void;
    /**
     * Records the source bound to a unit, keeping `_integerUnits` in step. Every per-unit write to
     * `_boundTextures` goes through here so the two can't drift apart.
     *
     * A unit has a separate binding per target (2D, 2D array, cube), and the batch shaders sample
     * the 2D target, so only a 2D source changes the unit's bit. Anything else, including null,
     * leaves it as it was: a bit left set after the integer texture is gone only costs one extra
     * `bind(Texture.EMPTY)` in `unbindIntegerTextures`, while a cleared bit over an integer texture
     * fails the next batch.
     * @param location - The texture unit.
     * @param source - The source now bound there, or null.
     */
    private _setBoundTexture;
    private _bindSampler;
    unbind(texture: BindableTexture): void;
    private _activateLocation;
    private _initSource;
    protected onStyleChange(source: TextureSource): void;
    protected updateStyle(source: TextureSource, firstCreation: boolean): void;
    protected onSourceUnload(source: TextureSource, contextLost?: boolean): void;
    protected onSourceUpdate(source: TextureSource): void;
    protected onUpdateMipmaps(source: TextureSource, bind?: boolean): void;
    private _initEmptyTexture2D;
    /**
     * Allocates a texture with a depth: the layers of a 2D array or the slices of a 3D texture.
     * Layer counts stay the same at every mip level; 3D depth halves like width and height.
     * @param glTexture - The GL texture wrapper.
     * @param source - The texture source describing the size.
     */
    private _initEmptyTexture3D;
    private _initEmptyTextureCube;
    /**
     * Applies a mip range to the currently-bound texture so WebGL2 considers the texture "mipmap complete"
     * for the declared `mipLevelCount` (especially important for partial mip chains rendered via FBO).
     * @param glTexture - The GL texture wrapper.
     * @param source - The texture source describing mipLevelCount.
     */
    private _applyMipRange;
    private _initSampler;
    private _getGlSampler;
    getGlSource(source: TextureSource): GlTexture;
    generateCanvas(texture: Texture): ICanvas;
    getPixels(texture: Texture): GetPixelsOutput;
    destroy(): void;
    resetState(): void;
}
