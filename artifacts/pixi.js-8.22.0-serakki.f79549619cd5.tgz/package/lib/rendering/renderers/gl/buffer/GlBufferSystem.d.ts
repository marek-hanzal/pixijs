import { ExtensionType } from '../../../../extensions/Extensions';
import { GCManagedHash } from '../../../../utils/data/GCManagedHash';
import { GlBuffer } from './GlBuffer';
import type { Buffer } from '../../shared/buffer/Buffer';
import type { System } from '../../shared/system/System';
import type { GlRenderingContext } from '../context/GlRenderingContext';
import type { WebGLRenderer } from '../WebGLRenderer';
/**
 * System plugin to the renderer to manage buffers.
 *
 * WebGL uses Buffers as a way to store objects to the GPU.
 * This system makes working with them a lot easier.
 *
 * Buffers are used in three main places in WebGL
 * - geometry information
 * - Uniform information (via uniform buffer objects - a WebGL 2 only feature)
 * - Transform feedback information. (WebGL 2 only feature)
 *
 * This system will handle the binding of buffers to the GPU as well as uploading
 * them. With this system, you never need to work directly with GPU buffers, but instead work with
 * the Buffer class.
 *
 * A buffer is first uploaded whole when a geometry or uniform block that uses it is bound. From then on
 * each `Buffer.update()` is applied as it is called, as on WebGPU, so every ranged update lands. On WebGL2
 * an index buffer's update goes through `COPY_WRITE_BUFFER`, so it changes no vertex array's index buffer.
 * @class
 * @category rendering
 * @advanced
 */
export declare class GlBufferSystem implements System {
    /** @ignore */
    static extension: {
        readonly type: readonly [ExtensionType.WebGLSystem];
        readonly name: "buffer";
    };
    /** @internal */
    _gl: GlRenderingContext;
    protected _managedBuffers: GCManagedHash<Buffer>;
    /**
     * What each uniform buffer binding slot holds, so an unchanged binding is not sent again.
     * A whole-buffer binding records a size of -1.
     */
    private _boundBuffers;
    private _boundOffsets;
    private _boundSizes;
    private _renderer;
    /**
     * @param {Renderer} renderer - The renderer this System works for.
     */
    constructor(renderer: WebGLRenderer);
    /** @ignore */
    destroy(): void;
    /** Sets up the renderer context and necessary buffers. */
    protected contextChange(): void;
    getGlBuffer(buffer: Buffer): GlBuffer;
    /**
     * This binds specified buffer. On first run, it will create the webGL buffers for the context too
     * @param buffer - the buffer to bind to the renderer
     */
    bind(buffer: Buffer): void;
    /**
     * Binds a whole uniform buffer to a binding slot.
     *
     * A cache is used so a buffer will not be bound again if already bound.
     * @param glBuffer - the buffer to bind
     * @param index - the binding slot to bind it to.
     */
    bindBufferBase(glBuffer: GlBuffer, index: number): void;
    /**
     * Binds part of a uniform buffer to a binding slot, so it is read from the offset supplied rather than 0.
     *
     * A cache is used so a range will not be bound again if already bound.
     * @param glBuffer - the buffer to bind, which must have been uploaded
     * @param index - the binding slot to bind it to, defaults to 0
     * @param offset - the byte offset to bind at, defaults to 0. Must be a multiple of
     * `renderer.limits.minUniformBufferOffsetAlignment`.
     * @param size - the number of bytes to bind, defaults to the rest of the buffer after `offset`
     */
    bindBufferRange(glBuffer: GlBuffer, index?: number, offset?: number, size?: number): void;
    /**
     * Will ensure the data in the buffer is uploaded to the GPU.
     *
     * Runs on each `update` event of a vertex or uniform buffer once it has a `GlBuffer`, and when a geometry
     * or uniform block that uses the buffer is bound. The second call for one update is a no-op.
     * @param {Buffer} buffer - the buffer to update
     */
    updateBuffer(buffer: Buffer): GlBuffer;
    /**
     * Uploads the buffer's latest update through `target`, if it has not been uploaded yet.
     * @param buffer - the buffer to upload
     * @param glBuffer - its `GlBuffer`
     * @param target - the binding point to upload through
     */
    private _upload;
    /**
     * dispose all WebGL resources of all managed buffers
     * @param contextLost
     */
    destroyAll(contextLost?: boolean): void;
    protected onBufferUnload(buffer: Buffer, contextLost?: boolean): void;
    /**
     * creates and attaches a GLBuffer object tied to the current context.
     * @param buffer
     * @protected
     */
    protected createGLBuffer(buffer: Buffer): GlBuffer;
    /**
     * Uploads an index buffer's update without changing any vertex array's index buffer.
     *
     * ELEMENT_ARRAY_BUFFER is vertex array state, so binding an index buffer there to upload it would make it
     * the index buffer of whichever vertex array is bound. WebGL2 uploads through COPY_WRITE_BUFFER instead,
     * which no vertex array reads. WebGL1 has no copy target, so it unbinds the vertex array first, and the
     * next `geometry.bind()` binds its own again.
     * @param buffer - the index buffer that was updated
     */
    private _updateIndexBuffer;
    resetState(): void;
}
