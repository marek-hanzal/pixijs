import { STENCIL_MODES } from '../shared/state/const';
/**
 * Represents a render target.
 * @category rendering
 * @ignore
 */
export declare class GlRenderTarget {
    width: number;
    height: number;
    msaa: boolean;
    /**
     * Tracks which mip level is currently attached to this render target's framebuffer.
     * This lets us skip redundant framebufferTexture2D calls on the common path.
     * @internal
     */
    _attachedMipLevel: number;
    /**
     * Tracks which array layer (or cube face index) is currently attached to this render target's framebuffer.
     * For non-array 2D textures this will always be 0.
     * @internal
     */
    _attachedLayer: number;
    framebuffer: WebGLFramebuffer;
    resolveTargetFramebuffer: WebGLFramebuffer;
    msaaRenderBuffer: WebGLRenderbuffer[];
    depthStencilRenderBuffer: WebGLRenderbuffer;
    /**
     * The stencil state the stencil system and the mask pipe track for this target on this renderer.
     * It lives here rather than in a uid-keyed record so it is restored when the target is bound again
     * and freed with the backend object when the target dies.
     */
    stencilMode: STENCIL_MODES;
    /** the stencil reference value that goes with `stencilMode` */
    stencilReference: number;
    /** how many stencil masks are currently pushed on this target */
    maskStackIndex: number;
}
