import type { PRECISION } from '../../const';
interface EnsurePrecisionOptions {
    requestedVertexPrecision: PRECISION;
    requestedFragmentPrecision: PRECISION;
    maxSupportedVertexPrecision: PRECISION;
    maxSupportedFragmentPrecision: PRECISION;
}
/**
 * Sets the float precision on the shader, ensuring the device supports the request precision.
 * If the precision is already present, it just ensures that the device is able to handle it.
 *
 * It also declares a precision for every sampler type the shader uses, unless the shader already declares one:
 * `lowp` for `sampler2D` and `samplerCube`, their GLSL default, and `highp` for every other type. GLSL ES 3.00
 * gives those types no default, so the shader wouldn't compile without one, and they mostly hold data, where a
 * lower precision would silently truncate values such as 32-bit integer ids.
 * @param src
 * @param options
 * @param options.requestedVertexPrecision
 * @param options.requestedFragmentPrecision
 * @param options.maxSupportedVertexPrecision
 * @param options.maxSupportedFragmentPrecision
 * @param isFragment
 * @private
 */
export declare function ensurePrecision(src: string, options: EnsurePrecisionOptions, isFragment: boolean): string;
export {};
