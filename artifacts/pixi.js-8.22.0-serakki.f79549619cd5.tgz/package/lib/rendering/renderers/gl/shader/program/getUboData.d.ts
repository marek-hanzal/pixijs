import type { GlUniformBlockData } from '../GlProgram';
/**
 * returns the uniform block data from the program
 * @private
 * @param program - the webgl program
 * @param gl - the WebGL context
 * @param firstBinding - the binding slot the first block reads from; each block takes the slot that many past its index
 * @returns {object} the uniform data for this program
 */
export declare function getUboData(program: WebGLProgram, gl: WebGL2RenderingContext, firstBinding?: number): Record<string, GlUniformBlockData>;
