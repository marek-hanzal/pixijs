import { BindGroup } from '../../renderers/gpu/shader/BindGroup';
import type { GCSystem } from '../../renderers/shared/GCSystem';
import type { TextureSource } from '../../renderers/shared/texture/sources/TextureSource';
/**
 * Registers the cache with a renderer GC, which destroys groups idle for longer than the GC's maxUnusedTime
 * @param gc - The GC system of the renderer.
 * @internal
 */
export declare function collectTextureBatchBindGroups(gc: GCSystem): void;
/**
 * Returns the cached bind group for a texture batch, building one when no live group binds these textures
 * @param textures - The texture sources of the batch.
 * @param size - How many of `textures` the batch uses.
 * @param maxTextures - The slot count of the batch shader.
 * @returns The group that binds `textures`, padded with `Texture.EMPTY` up to `maxTextures` slots.
 * @internal
 */
export declare function getTextureBatchBindGroup(textures: TextureSource[], size: number, maxTextures: number): BindGroup;
