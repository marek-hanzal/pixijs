import type { TextureSource } from '../rendering/renderers/shared/texture/sources/TextureSource';
/**
 * @experimental
 * The resource types the HTML texture uploaders can handle: a live DOM {@link Element}
 * (via {@link HTMLSource}) or an immutable {@link ElementImage} snapshot
 * (via {@link ElementImageSource}).
 * @category rendering
 * @advanced
 */
export type HTMLSourceResource = Element | ElementImage;
/**
 * @experimental
 * An {@link HTMLCanvasElement} extended with the experimental HTML-in-Canvas proposal APIs.
 *
 * These members only exist in browsers that have the HTML-in-Canvas feature enabled, so they
 * are optional. {@link HTMLSource} feature-detects `requestPaint`; the HTML-in-Canvas API must
 * be enabled for the texture to upload.
 * @example
 * ```ts
 * import type { HTMLSourceCanvas } from 'pixi.js/html-source';
 *
 * const canvas = app.canvas as HTMLSourceCanvas;
 *
 * // Feature-detect before relying on the experimental API.
 * if (canvas.requestPaint)
 * {
 *     canvas.requestPaint();
 * }
 * ```
 * @see {@link HTMLSource} For the texture source that drives these APIs
 * @see {@link ElementImage} For the snapshot type `captureElementImage()` returns
 * @category rendering
 * @advanced
 */
export interface HTMLSourceCanvas extends HTMLCanvasElement {
    /** Requests a `paint` event so the canvas re-snapshots its `drawable` descendants. */
    requestPaint?: () => void;
    /** Captures the current rendered pixels of `element` into an immutable {@link ElementImage}. */
    captureElementImage?: (element: Element) => ElementImage;
    /**
     * Chrome 155+. Tells the browser where `element` was drawn so it can hit test the element
     * and report its bounds to assistive technology. WebGL and WebGPU drawing never does this
     * for you. `canvasTransform` maps the element's border box, before CSS transforms, to canvas
     * CSS pixels. Older builds read the element's CSS `transform` instead.
     * @example
     * ```ts
     * const canvas = app.canvas as HTMLSourceCanvas;
     * const { a, b, c, d, tx, ty } = sprite.getGlobalTransform();
     * const canvasTransform = new DOMMatrix([a, b, c, d, tx, ty]).translate(
     *     -sprite.anchor.x * sprite.texture.width,
     *     -sprite.anchor.y * sprite.texture.height,
     * );
     *
     * canvas.updateElementGeometry?.(element, { canvasTransform });
     * ```
     */
    updateElementGeometry?: (element: HTMLSourceResource, options?: {
        canvasTransform?: DOMMatrixInit;
        canvasClip?: DOMRectInit;
        preserveHitTestOrder?: boolean;
    }) => void;
    /** Chrome 155+. Clears the geometry set by {@link HTMLSourceCanvas.updateElementGeometry}. */
    clearElementGeometry?: (element: HTMLSourceResource) => void;
}
/**
 * @experimental
 * A snapshot produced by the experimental HTML-in-Canvas `captureElementImage()` API.
 *
 * A snapshot is a frozen, immutable copy of an element's rendered pixels at the moment it was
 * captured. Unlike a live {@link HTMLSource} element, it never repaints, so it is a good fit
 * for effects that need a stable image (transitions, "shatter" effects, trails). Snapshots are
 * transferable and cheap to keep around; rendering live elements is what most apps reach for.
 *
 * Call {@link ElementImage.close} (or set {@link ElementImageSourceOptions.autoClose}) to
 * release the underlying memory once you are done.
 * @example
 * ```ts
 * import { ElementImageSource, Sprite } from 'pixi.js/html-source';
 * import type { HTMLSourceCanvas } from 'pixi.js/html-source';
 *
 * const canvas = app.canvas as HTMLSourceCanvas;
 *
 * // Freeze the current pixels of an element into an immutable snapshot.
 * const snapshot = canvas.captureElementImage!(element);
 *
 * const source = new ElementImageSource({ resource: snapshot });
 * const sprite = Sprite.from(source);
 * ```
 * @see {@link ElementImageSource} For rendering a snapshot as a texture
 * @see {@link HTMLSourceCanvas} For the canvas API that produces snapshots
 * @see {@link HTMLSource} For rendering a live, repainting element instead
 * @category rendering
 * @advanced
 */
export interface ElementImage {
    /** The width of the captured snapshot, in pixels. */
    readonly width: number;
    /** The height of the captured snapshot, in pixels. */
    readonly height: number;
    /** Releases the memory backing this snapshot. The snapshot must not be used afterwards. */
    close(): void;
}
/**
 * @experimental
 * The minimal source shape the HTML texture uploaders consume. Both {@link HTMLSource} and
 * {@link ElementImageSource} satisfy it, so a single set of `'html'` uploaders covers the
 * live-element and snapshot cases.
 * @category rendering
 * @internal
 */
export interface HTMLUploadableSource extends TextureSource {
    /** A live DOM element or an immutable snapshot. */
    readonly resource: HTMLSourceResource;
    /** Whether the source has pixels ready to upload. */
    readonly isReady: boolean;
    /** Present only on live {@link HTMLSource}; snapshots never repaint. */
    requestPaint?(): boolean;
}
